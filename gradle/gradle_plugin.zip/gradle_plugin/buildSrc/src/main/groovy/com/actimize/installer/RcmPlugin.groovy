

class GreetingPlugin implements Plugin<Project> {
	void apply(Project project) {
		project.task('rcm') {
			println "Hello world!"
		}
	}
}